===================================================================
             ⚡ KritiAI - Personal AI Operating System
        "Your Personal AI That Gets Things Done."
===================================================================

Thank you for downloading KritiAI for Windows!

DEFAULT RUNTIME PORT: 9972
(Accessible in your browser at: http://localhost:9972)

QUICK START INSTRUCTIONS:
1. Double-click 'KritiAI.exe' (or 'KritiAI-Launcher.bat') to launch KritiAI instantly with 1-click.
2. The native desktop kernel starts automatically and opens the desktop interface.
3. Link with the website:
   - On the website (https://kritiai.vercel.app), click "Pair Desktop".
   - Enter the 6-digit alphanumeric code (e.g. KR72B9).
   - Your website and desktop app are now connected and will auto-reconnect!
4. Real Superpowers Active:
   - Live PowerShell / CMD terminal execution.
   - AI Code Studio: generate code with Groq Llama 3.3 70B or Gemini.
   - Create files and folders directly in your chosen workspace directory.
   - Run Python, Node.js, PowerShell, and Batch scripts with live logs.

SECURITY & VERIFICATION:
- 100% clean and transparent scripts.
- No malicious code, no false-positive virus detections.
- Runs completely offline when paired with local Ollama.

Documentation: https://kritiai.vercel.app/docs
Support: support@kritiai.app
