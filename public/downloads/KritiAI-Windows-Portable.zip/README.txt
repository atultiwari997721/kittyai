===================================================================
             ⚡ KritiAI - Personal AI Operating System
        "Your Personal AI That Gets Things Done."
===================================================================

Thank you for downloading KritiAI for Windows!

DEFAULT RUNTIME PORT: 9972
(Accessible in your browser at: http://localhost:9972)

QUICK START INSTRUCTIONS:
1. Double-click 'KritiAI-Setup.bat' to launch KritiAI.
2. The launcher will check Python, Ollama, start the local AI sidecar on port 8000, and launch the assistant on port 9972.
3. Use the floating Assist HUD shortcut: Ctrl+Shift+Space (or Alt+K) anytime.

SECURITY & VERIFICATION:
- 100% clean and transparent scripts.
- No malicious code, no false-positive virus detections.
- Runs completely offline when paired with local Ollama.

Documentation: https://kritiai.vercel.app/docs
Support: support@kritiai.app
