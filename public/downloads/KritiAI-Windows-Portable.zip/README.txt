KritiAI - Autonomous Personal AI Operating System
==================================================
"Your Personal AI That Gets Things Done."

QUICK START:
1. Double click 'KritiAI-Setup.bat' (or right-click 'Install-KritiAI.ps1' -> Run with PowerShell).
2. The KritiAI local assistant will start on your Windows desktop.
3. Use Ctrl+Shift+Space to toggle Assist HUD anywhere.
4. For completely offline private models, install Ollama from https://ollama.com

Documentation & Web: https://kritiai.vercel.app
